<?php
/**
 * Bloc « Programmes phares » : une carte par catégorie avec ses règles d'examen.
 *
 * @package LearnDriveCore
 *
 * @var array $attributes Attributs.
 */

use LearnDrive\Core\Blocks;
use function LearnDrive\Core\setting;
use const LearnDrive\Core\TAX_TRACK;

defined( 'ABSPATH' ) || exit;

// Pays : réglage du bloc, sinon le marché de la page (hub d'un pays), sinon le marché principal.
$learn_drive_country = '' !== $attributes['country'] ? $attributes['country'] : \LearnDrive\Core\Markets\current();
$learn_drive_country = $learn_drive_country ? $learn_drive_country : (string) setting( 'default_country' );
$learn_drive_args    = array(
	'taxonomy'   => TAX_TRACK,
	'hide_empty' => false,
);
if ( $learn_drive_country && 'all' !== $learn_drive_country ) {
	$learn_drive_args['meta_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		array(
			'key'   => 'ld_country',
			'value' => $learn_drive_country,
		),
	);
}
$learn_drive_terms = get_terms( $learn_drive_args );
if ( ! $learn_drive_terms || is_wp_error( $learn_drive_terms ) ) {
	return;
}
// Ordre éditorial (méta ld_order), puis les catégories les plus fournies.
usort(
	$learn_drive_terms,
	static function ( $a, $b ) {
		$order = (int) get_term_meta( $a->term_id, 'ld_order', true ) <=> (int) get_term_meta( $b->term_id, 'ld_order', true );
		return $order ? $order : $b->count <=> $a->count;
	}
);
// Mode « examens » : seulement les catégories qui ont un examen blanc ; les autres sont annoncées à part.
$learn_drive_exams   = 'exams' === ( $attributes['mode'] ?? 'all' );
$learn_drive_pending = array();
if ( $learn_drive_exams ) {
	$learn_drive_with = array();
	foreach ( $learn_drive_terms as $learn_drive_term ) {
		if ( \LearnDrive\Core\Permalinks\exam_for_track( $learn_drive_term ) ) {
			$learn_drive_with[] = $learn_drive_term;
		} else {
			$learn_drive_pending[] = sprintf( '<a href="%s">%s</a>', esc_url( get_term_link( $learn_drive_term ) ), esc_html( $learn_drive_term->name ) );
		}
	}
	$learn_drive_terms = $learn_drive_with;
}
$learn_drive_terms = array_slice( $learn_drive_terms, 0, max( 1, min( 24, (int) $attributes['count'] ) ) );

$learn_drive_items = '';
foreach ( $learn_drive_terms as $learn_drive_term ) {
	$learn_drive_summary = Blocks\track_summary( $learn_drive_term );
	$learn_drive_color   = sanitize_hex_color( (string) get_term_meta( $learn_drive_term->term_id, 'ld_color', true ) );
	$learn_drive_facts   = '';
	foreach ( $learn_drive_summary['facts'] as $learn_drive_fact ) {
		$learn_drive_facts .= '<li>' . esc_html( $learn_drive_fact ) . '</li>';
	}
	$learn_drive_stats = array();
	if ( $learn_drive_summary['lessons'] ) {
		/* translators: %d: number of lessons */
		$learn_drive_stats[] = sprintf( _n( '%d leçon', '%d leçons', $learn_drive_summary['lessons'], 'learn-drive-core' ), $learn_drive_summary['lessons'] );
	}
	if ( $learn_drive_summary['quizzes'] ) {
		/* translators: %d: number of quizzes */
		$learn_drive_stats[] = sprintf( _n( '%d quiz', '%d quiz', $learn_drive_summary['quizzes'], 'learn-drive-core' ), $learn_drive_summary['quizzes'] );
	}

	$learn_drive_items .= sprintf(
		'<li class="ld-track"%1$s><span class="ld-track__icon">%2$s</span><h3 class="ld-track__name"><a href="%3$s">%4$s</a></h3>%5$s%6$s%7$s%8$s</li>',
		$learn_drive_color ? ' style="--ld-track:' . esc_attr( $learn_drive_color ) . '"' : '',
		Blocks\track_icon( $learn_drive_term->slug ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- SVG construit et échappé.
		esc_url( get_term_link( $learn_drive_term ) ),
		esc_html( $learn_drive_term->name ),
		$learn_drive_term->description ? '<p class="ld-track__desc">' . esc_html( wp_trim_words( $learn_drive_term->description, 22 ) ) . '</p>' : '',
		$learn_drive_facts ? '<ul class="ld-track__facts">' . $learn_drive_facts . '</ul>' : '',
		$learn_drive_stats ? '<p class="ld-track__stats">' . esc_html( implode( ' · ', $learn_drive_stats ) ) . '</p>' : '',
		$learn_drive_summary['exam'] ? '<a class="ld-track__exam" href="' . esc_url( get_permalink( $learn_drive_summary['exam'] ) ) . '">' . ( $learn_drive_exams ? esc_html__( 'Commencer l’examen blanc', 'learn-drive-core' ) : esc_html__( 'Examen blanc', 'learn-drive-core' ) ) . '<span aria-hidden="true"> →</span></a>' : ''
	);
}

printf(
	'<div %1$s><ul class="ld-tracks__list%2$s">%3$s</ul>%4$s</div>',
	get_block_wrapper_attributes( array( 'class' => 'ld-tracks is-' . esc_attr( $attributes['layout'] ) ) ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	'carousel' === $attributes['layout'] ? ' ld-carousel' : '',
	$learn_drive_items, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- échappé à la construction.
	$learn_drive_pending ? '<p class="ld-tracks__pending">' . esc_html__( 'Examens blancs en préparation :', 'learn-drive-core' ) . ' ' . implode( ', ', $learn_drive_pending ) . '</p>' : '' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- liens échappés à la construction.
);
