<?php
/**
 * Politique d'indexation : seules les pages qui apportent une vraie réponse
 * sont proposées aux moteurs de recherche.
 *
 * Exclues automatiquement (noindex, follow + retrait des sitemaps) :
 * - contenus trop courts (seuil de mots par type, réglable) ;
 * - catégories, rubriques, étiquettes et thèmes avec trop peu de contenus et
 *   sans texte d'introduction suffisant ;
 * - auteurs avec trop peu d'articles ou sans biographie ;
 * - archives par date, pages de fichiers joints, archives vides, flux.
 *
 * Les questions gardent leur propre règle (explication obligatoire, voir
 * questions.php) ; l'accueil et la page des actualités ne sont jamais exclus.
 *
 * @package LearnDriveCore
 */

namespace LearnDrive\Core\SEO\Index;

use function LearnDrive\Core\setting;
use function LearnDrive\Core\word_count;
use const LearnDrive\Core\PT_COURSE;
use const LearnDrive\Core\PT_LESSON;
use const LearnDrive\Core\PT_QUESTION;
use const LearnDrive\Core\PT_SHEET;
use const LearnDrive\Core\PT_GUIDE;
use const LearnDrive\Core\PT_GLOSSARY;
use const LearnDrive\Core\PT_QUIZ;
use const LearnDrive\Core\TAX_TRACK;
use const LearnDrive\Core\TAX_TOPIC;
use const LearnDrive\Core\TAX_FAMILY;
use const LearnDrive\Core\TAX_COUNTRY;

defined( 'ABSPATH' ) || exit;

/**
 * Nombre minimal de mots par type de contenu pour être indexé.
 *
 * Les fiches et le lexique sont courts par nature ; un quiz se juge sur ses
 * questions (voir is_thin_post()).
 *
 * @return array<string,int>
 */
function min_words() {
	$base = max( 0, (int) setting( 'index_min_words' ) );
	$min  = array(
		'post'      => $base,
		PT_GUIDE    => $base,
		PT_LESSON   => $base,
		PT_COURSE   => (int) round( $base * 0.6 ),
		'page'      => (int) round( $base * 0.6 ),
		PT_SHEET    => (int) round( $base * 0.3 ),
		PT_GLOSSARY => (int) round( $base * 0.2 ),
	);

	/**
	 * Seuils de mots par type de contenu en dessous desquels la page n'est pas indexée.
	 *
	 * @param array<string,int> $min Seuils.
	 */
	return apply_filters( 'learn_drive_index_min_words', $min );
}

/**
 * La politique est-elle active ?
 *
 * @return bool
 */
function enabled() {
	return (bool) setting( 'index_policy' );
}

/**
 * Un contenu est-il trop mince pour être indexé ?
 *
 * @param int|\WP_Post $post Contenu.
 * @return bool
 */
function is_thin_post( $post ) {
	$post = get_post( $post );
	if ( ! $post || ! enabled() ) {
		return false;
	}

	if ( 'page' === $post->post_type && in_array( (int) $post->ID, array( (int) get_option( 'page_on_front' ), (int) get_option( 'page_for_posts' ) ), true ) ) {
		return false;
	}

	if ( PT_QUIZ === $post->post_type ) {
		return count( \LearnDrive\Core\Quizzes\question_ids( $post->ID ) ) < 5;
	}

	// Une question se juge sur son explication rédigée (règle propre aux questions).
	if ( PT_QUESTION === $post->post_type ) {
		return \LearnDrive\Core\Questions\is_thin( $post->ID );
	}

	// Un cours se juge aussi sur son programme : ses leçons s'affichent sur sa page.
	if ( PT_COURSE === $post->post_type && count( \LearnDrive\Core\Blocks\course_lessons( $post->ID ) ) >= 3 ) {
		return false;
	}

	$min = min_words();
	if ( ! isset( $min[ $post->post_type ] ) ) {
		return false;
	}

	return word_count( $post->post_content ) < $min[ $post->post_type ];
}

/**
 * Met à jour le drapeau noindex d'un contenu (hors questions) à l'enregistrement.
 *
 * @param int $post_id Contenu.
 */
function update_flag( $post_id ) {
	if ( PT_QUESTION === get_post_type( $post_id ) ) {
		\LearnDrive\Core\Questions\update_seo_flags( $post_id ); // Règle propre aux questions.
		return;
	}
	$post = get_post( $post_id );
	if ( ! $post || wp_is_post_revision( $post_id ) || 'publish' !== $post->post_status || ! in_array( $post->post_type, array_merge( array_keys( min_words() ), array( PT_QUIZ ) ), true ) ) {
		return;
	}
	$thin = is_thin_post( $post );
	update_post_meta( $post_id, '_ld_words', word_count( $post->post_content ) );

	if ( $thin || get_post_meta( $post_id, '_ld_seo_noindex', true ) || get_post_meta( $post_id, '_ld_canonical', true ) ) {
		update_post_meta( $post_id, '_ld_noindex', 1 );
		update_post_meta( $post_id, '_ld_thin', $thin ? 1 : 0 );
	} else {
		delete_post_meta( $post_id, '_ld_noindex' );
		delete_post_meta( $post_id, '_ld_thin' );
	}
}
add_action( 'save_post', __NAMESPACE__ . '\\update_flag', 30 );

/**
 * Recalcule les drapeaux de tous les contenus (changement de seuil, mise à jour).
 *
 * @return int Nombre de contenus exclus.
 */
function recompute() {
	// Par lots (une banque officielle compte des milliers de questions).
	$types  = array_merge( array_keys( min_words() ), array( PT_QUIZ, PT_QUESTION ) );
	$offset = (int) get_option( 'ld_index_recompute_offset', 0 );
	$ids    = get_posts(
		array(
			'post_type'      => $types,
			'post_status'    => 'publish',
			'posts_per_page' => 400,
			'offset'         => $offset,
			'orderby'        => 'ID',
			'order'          => 'ASC',
			'fields'         => 'ids',
		)
	);
	$count  = 0;
	foreach ( $ids as $id ) {
		update_flag( $id );
		$count += (int) (bool) get_post_meta( $id, '_ld_thin', true );
	}
	if ( count( $ids ) === 400 ) {
		update_option( 'ld_index_recompute_offset', $offset + 400, false );
		wp_schedule_single_event( time() + 15, 'learn_drive_index_recompute' );
	} else {
		delete_option( 'ld_index_recompute_offset' );
	}
	return $count;
}
add_action( 'update_option_' . \LearnDrive\Core\OPTION, __NAMESPACE__ . '\\schedule_recompute' );

/**
 * Programme un recalcul après une modification des réglages.
 */
function schedule_recompute() {
	if ( ! wp_next_scheduled( 'learn_drive_index_recompute' ) ) {
		wp_schedule_single_event( time() + 10, 'learn_drive_index_recompute' );
	}
}
add_action( 'learn_drive_index_recompute', __NAMESPACE__ . '\\recompute' );

/**
 * Nombre de mots d'introduction d'un terme (description + texte de la page pilier).
 *
 * @param \WP_Term $term Terme.
 * @return int
 */
function term_words( $term ) {
	return word_count( $term->description . ' ' . (string) get_term_meta( $term->term_id, 'ld_content', true ) );
}

/**
 * Une archive de terme est-elle trop mince pour être indexée ?
 *
 * Un terme est indexé s'il réunit assez de contenus OU s'il porte un vrai
 * texte d'introduction (page pilier).
 *
 * @param \WP_Term $term Terme.
 * @return bool
 */
function is_thin_term( $term ) {
	if ( ! $term instanceof \WP_Term || ! enabled() ) {
		return false;
	}
	// Pages de liste sans texte propre (thèmes, sous-rubriques) : indexées
	// seulement avec une vraie introduction rédigée, quel que soit le nombre de contenus.
	if ( TAX_TOPIC === $term->taxonomy || ( 'category' === $term->taxonomy && $term->parent ) ) {
		return term_words( $term ) < listing_min_words();
	}
	$min_items = max( 1, (int) setting( 'index_min_items' ) );
	if ( 'post_tag' === $term->taxonomy ) {
		$min_items *= 2;
	}
	return term_count( $term ) < $min_items && term_words( $term ) < 120;
}

/**
 * Mots d'introduction rédigée exigés d'une page de liste (thème, sous-rubrique,
 * archive de quiz) pour être indexée.
 *
 * @return int
 */
function listing_min_words() {
	/**
	 * Mots d'introduction exigés d'une page de liste pour être indexée.
	 *
	 * @param int $words Mots.
	 */
	return (int) apply_filters( 'learn_drive_listing_min_words', 300 );
}

/**
 * Archive de questions ou de quiz (globale : /quiz/, ou par catégorie :
 * /patente-b/quiz/, /patente-b/domande/) : une liste de liens, sans texte
 * propre — la page de la catégorie et les quiz eux-mêmes portent le contenu.
 * Une archive de quiz avec une introduction rédigée reste indexable.
 *
 * @return bool
 */
function is_listing_archive() {
	$type = get_query_var( 'post_type' );
	$type = is_array( $type ) ? reset( $type ) : (string) $type;
	if ( ! in_array( $type, array( PT_QUESTION, PT_QUIZ ), true ) || ! ( is_post_type_archive() || is_tax( TAX_TRACK ) ) ) {
		return false;
	}
	return PT_QUESTION === $type || word_count( (string) get_option( 'ld_archive_intro_' . PT_QUIZ ) ) < listing_min_words();
}

/**
 * Nombre de contenus d'un terme, sous-termes compris pour les taxonomies
 * hiérarchiques (une rubrique parente dont les articles sont tous rangés
 * dans ses sous-rubriques n'est pas mince : son archive les affiche).
 *
 * @param \WP_Term $term Terme.
 * @return int
 */
function term_count( \WP_Term $term ) {
	$count = (int) $term->count;
	if ( is_taxonomy_hierarchical( $term->taxonomy ) ) {
		$children = get_terms(
			array(
				'taxonomy'   => $term->taxonomy,
				'child_of'   => $term->term_id,
				'hide_empty' => false,
				'fields'     => 'all',
			)
		);
		foreach ( is_array( $children ) ? $children : array() as $child ) {
			$count += (int) $child->count;
		}
	}
	return $count;
}

/**
 * Taxonomies concernées par la règle des termes minces.
 *
 * @return string[]
 */
function taxonomies() {
	return array( 'category', 'post_tag', TAX_TRACK, TAX_TOPIC, TAX_FAMILY, TAX_COUNTRY );
}

/**
 * Un auteur est-il trop mince (peu d'articles, pas de biographie) ?
 *
 * @param int $user_id Auteur.
 * @return bool
 */
function is_thin_author( $user_id ) {
	if ( ! enabled() ) {
		return false;
	}
	$posts = (int) count_user_posts( $user_id, array( 'post', PT_GUIDE, PT_LESSON ), true );
	$bio   = word_count( (string) get_the_author_meta( 'description', $user_id ) );
	return $posts < max( 1, (int) setting( 'index_min_items' ) ) || $bio < 20;
}

/**
 * Décision pour la page courante (branchée sur le filtre learn_drive_noindex).
 *
 * @param bool $noindex Décision précédente.
 * @return bool
 */
function current_page( $noindex ) {
	if ( $noindex || ! enabled() || is_front_page() || is_home() ) {
		return $noindex;
	}
	if ( is_date() || is_attachment() || is_feed() ) {
		return true;
	}
	if ( is_singular() && ! is_singular( PT_QUESTION ) ) {
		return (bool) get_post_meta( get_queried_object_id(), '_ld_thin', true ) || is_thin_post( get_queried_object() );
	}
	if ( is_listing_archive() ) {
		return true;
	}
	if ( is_category() || is_tag() || is_tax( taxonomies() ) ) {
		return is_thin_term( get_queried_object() );
	}
	if ( is_author() ) {
		return is_thin_author( get_queried_object_id() );
	}
	if ( is_post_type_archive() && ! have_posts() ) {
		return true;
	}
	// Archives des questions et des quiz (globales ou par catégorie) : des listes
	// de liens. Les quiz eux-mêmes et la page de la catégorie portent le texte.
	if ( is_listing_archive() ) {
		return true;
	}
	return $noindex;
}
add_filter( 'learn_drive_noindex', __NAMESPACE__ . '\\current_page' );

/**
 * Flux RSS : jamais dans l'index (en-tête HTTP, envoyé avant le flux).
 */
function feed_header() {
	if ( enabled() && is_feed() && ! headers_sent() ) {
		header( 'X-Robots-Tag: noindex, follow', true );
	}
}
add_action( 'template_redirect', __NAMESPACE__ . '\\feed_header', 0 );

/**
 * Sitemaps : retire les termes minces.
 *
 * @param array  $args     Arguments de requête.
 * @param string $taxonomy Taxonomie.
 * @return array
 */
function sitemap_terms( $args, $taxonomy ) {
	if ( ! enabled() || ! in_array( $taxonomy, taxonomies(), true ) ) {
		return $args;
	}
	$terms   = get_terms(
		array(
			'taxonomy'   => $taxonomy,
			'hide_empty' => false,
		)
	);
	$exclude = array();
	foreach ( is_wp_error( $terms ) ? array() : $terms as $term ) {
		if ( is_thin_term( $term ) ) {
			$exclude[] = $term->term_id;
		}
	}
	if ( $exclude ) {
		$args['exclude'] = array_merge( (array) ( $args['exclude'] ?? array() ), $exclude );
	}
	// Rubriques parentes sans contenu direct : gardées si leurs sous-rubriques en ont.
	$args['hide_empty'] = false;
	return $args;
}
add_filter( 'wp_sitemaps_taxonomies_query_args', __NAMESPACE__ . '\\sitemap_terms', 10, 2 );

/**
 * Sitemaps : retire les auteurs minces.
 *
 * @param array $args Arguments de requête.
 * @return array
 */
function sitemap_users( $args ) {
	if ( ! enabled() ) {
		return $args;
	}
	$authors = get_users(
		array(
			'has_published_posts' => true,
			'fields'              => 'ID',
		)
	);
	$exclude = array_values( array_filter( array_map( 'intval', $authors ), __NAMESPACE__ . '\\is_thin_author' ) );
	if ( $exclude ) {
		$args['exclude'] = array_merge( (array) ( $args['exclude'] ?? array() ), $exclude );
	}
	return $args;
}
add_filter( 'wp_sitemaps_users_query_args', __NAMESPACE__ . '\\sitemap_users' );

/**
 * Sitemaps : pas de pages en sitemap pour les types sans page utile.
 *
 * @param array $post_types Types.
 * @return array
 */
function sitemap_post_types( $post_types ) {
	unset( $post_types['attachment'] );
	return $post_types;
}
add_filter( 'wp_sitemaps_post_types', __NAMESPACE__ . '\\sitemap_post_types' );

/**
 * Liste des pages exclues (écran Santé SEO).
 *
 * @return array{posts:int[],terms:\WP_Term[]}
 */
function report() {
	$posts = get_posts(
		array(
			'post_type'      => 'any',
			'posts_per_page' => 200,
			'fields'         => 'ids',
			'meta_key'       => '_ld_thin', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_value'     => 1, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		)
	);
	$terms = array();
	foreach ( taxonomies() as $taxonomy ) {
		$list = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
			)
		);
		foreach ( is_wp_error( $list ) ? array() : $list as $term ) {
			if ( is_thin_term( $term ) ) {
				$terms[] = $term;
			}
		}
	}
	return compact( 'posts', 'terms' );
}

/**
 * Yoast SEO : mêmes exclusions dans ses sitemaps (contenus, termes, auteurs).
 *
 * @param int[] $ids Identifiants déjà exclus.
 * @return int[]
 */
function yoast_exclude_posts( $ids ) {
	if ( ! enabled() ) {
		return $ids;
	}
	$thin = get_posts(
		array(
			'post_type'      => 'any',
			'post_status'    => 'publish',
			'posts_per_page' => -1, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- identifiants seulement, mis en cache par Yoast.
			'fields'         => 'ids',
			'meta_key'       => '_ld_noindex', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
		)
	);
	return array_values( array_unique( array_merge( (array) $ids, array_map( 'intval', $thin ) ) ) );
}
add_filter( 'wpseo_exclude_from_sitemap_by_post_ids', __NAMESPACE__ . '\\yoast_exclude_posts' );

/**
 * Yoast SEO : termes minces hors sitemap.
 *
 * @param int[] $ids Identifiants déjà exclus.
 * @return int[]
 */
function yoast_exclude_terms( $ids ) {
	if ( ! enabled() ) {
		return $ids;
	}
	return array_values( array_unique( array_merge( (array) $ids, wp_list_pluck( report()['terms'], 'term_id' ) ) ) );
}
add_filter( 'wpseo_exclude_from_sitemap_by_term_ids', __NAMESPACE__ . '\\yoast_exclude_terms' );

/**
 * Yoast SEO : pas de sitemap pour une taxonomie dont aucun terme n'est
 * indexable (un sitemap vide ou fait de pages noindex est une erreur dans
 * la Search Console).
 *
 * @param bool   $excluded Exclue.
 * @param string $taxonomy Taxonomie.
 * @return bool
 */
function yoast_exclude_taxonomy( $excluded, $taxonomy ) {
	if ( $excluded || ! enabled() || ! in_array( $taxonomy, taxonomies(), true ) ) {
		return $excluded;
	}
	$terms = get_terms(
		array(
			'taxonomy'   => $taxonomy,
			'hide_empty' => false,
		)
	);
	if ( is_wp_error( $terms ) || ! $terms ) {
		return $excluded;
	}
	foreach ( $terms as $term ) {
		if ( ! is_thin_term( $term ) ) {
			return false;
		}
	}
	return true;
}
add_filter( 'wpseo_sitemap_exclude_taxonomy', __NAMESPACE__ . '\\yoast_exclude_taxonomy', 10, 2 );

/**
 * Yoast SEO : pas d'archive noindex (questions, quiz sans introduction) dans
 * les sitemaps.
 *
 * @param string|false $link      Adresse de l'archive.
 * @param string       $post_type Type.
 * @return string|false
 */
function yoast_archive_link( $link, $post_type ) {
	if ( ! enabled() ) {
		return $link;
	}
	if ( PT_QUESTION === $post_type ) {
		return false;
	}
	if ( PT_QUIZ === $post_type && word_count( (string) get_option( 'ld_archive_intro_' . PT_QUIZ ) ) < listing_min_words() ) {
		return false;
	}
	return $link;
}
add_filter( 'wpseo_sitemap_post_type_archive_link', __NAMESPACE__ . '\\yoast_archive_link', 10, 2 );

/**
 * Yoast SEO masque les termes sans contenu direct, dont les rubriques parentes
 * qui rangent tout dans leurs sous-rubriques : la règle des termes minces
 * (sous-termes compris) décide à sa place.
 *
 * @param bool $hide_empty Masquer les termes vides.
 * @return bool
 */
function yoast_keep_parent_terms( $hide_empty ) {
	return enabled() ? false : $hide_empty;
}
add_filter( 'wpseo_sitemap_exclude_empty_terms', __NAMESPACE__ . '\\yoast_keep_parent_terms' );

/**
 * Yoast SEO : auteurs minces hors sitemap (le filtre reçoit la liste des auteurs retenus).
 *
 * @param \WP_User[] $users Auteurs.
 * @return \WP_User[]
 */
function yoast_exclude_authors( $users ) {
	if ( ! enabled() || ! is_array( $users ) ) {
		return $users;
	}
	return array_values( array_filter( $users, static fn( $user ) => ! ( $user instanceof \WP_User && is_thin_author( $user->ID ) ) ) );
}
add_filter( 'wpseo_sitemap_exclude_author', __NAMESPACE__ . '\\yoast_exclude_authors' );

/*
 * Banques de questions officielles (milliers d'affirmations d'une phrase) :
 * leurs pages servent aux élèves, pas à Google. Réglage « crawl_questions »
 * désactivé : exploration interdite (robots.txt), hors sitemaps, et plus de
 * listes de liens vers elles. Le budget d'exploration va aux pages utiles.
 */

/**
 * Les pages question peuvent-elles être explorées ?
 *
 * @return bool
 */
function questions_crawlable() {
	return (bool) setting( 'crawl_questions' );
}

/**
 * Les pages question vont-elles dans les sitemaps ? Seulement si elles sont
 * explorables et qu'au moins une est assez rédigée pour être indexée : un
 * sitemap ne doit lister que des pages indexables.
 *
 * @return bool
 */
function questions_in_sitemap() {
	return questions_crawlable() && \LearnDrive\Core\Questions\indexable_count() > 0;
}

/**
 * Segments d'URL des questions (site et marchés).
 *
 * @return string[]
 */
function question_segments() {
	$segments = array( (string) setting( 'slug_question' ) );
	if ( function_exists( 'LearnDrive\Core\Markets\all' ) ) {
		foreach ( \LearnDrive\Core\Markets\all() as $market ) {
			if ( ! empty( $market['slugs']['slug_question'] ) ) {
				$segments[] = $market['slugs']['slug_question'];
			}
		}
	}
	return array_values( array_unique( array_filter( $segments ) ) );
}

/**
 * Fichier robots.txt : pages question non explorées (si le réglage le demande).
 *
 * @param string $output    Contenu.
 * @param bool   $is_public Site public.
 * @return string
 */
function robots_questions( $output, $is_public ) {
	if ( ! $is_public || questions_crawlable() ) {
		return $output;
	}
	$rules = '';
	foreach ( question_segments() as $segment ) {
		$rules .= "Disallow: /{$segment}/\nDisallow: /*/{$segment}/\n";
	}
	// Ajouté au groupe « User-agent: * » de WordPress.
	if ( str_contains( $output, "User-agent: *\n" ) ) {
		return preg_replace( "/User-agent: \*\n/", "User-agent: *\n" . $rules, $output, 1 );
	}
	return "User-agent: *\n" . $rules . "\n" . $output;
}
add_filter( 'robots_txt', __NAMESPACE__ . '\\robots_questions', 5, 2 );

/**
 * Sitemaps de WordPress : pas de sitemap des questions.
 *
 * @param array $types Types.
 * @return array
 */
function sitemap_no_questions( $types ) {
	if ( ! questions_in_sitemap() ) {
		unset( $types[ \LearnDrive\Core\PT_QUESTION ] );
	}
	return $types;
}
add_filter( 'wp_sitemaps_post_types', __NAMESPACE__ . '\\sitemap_no_questions', 20 );

/**
 * Yoast SEO : pas de sitemap des questions.
 *
 * @param bool   $excluded  Exclu.
 * @param string $post_type Type.
 * @return bool
 */
function yoast_no_questions( $excluded, $post_type ) {
	return $excluded || ( \LearnDrive\Core\PT_QUESTION === $post_type && ! questions_in_sitemap() );
}
add_filter( 'wpseo_sitemap_exclude_post_type', __NAMESPACE__ . '\\yoast_no_questions', 10, 2 );
